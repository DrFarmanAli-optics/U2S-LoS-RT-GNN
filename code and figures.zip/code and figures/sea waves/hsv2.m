clc;
clear all;

% Path for data files
csv_path = 'F:\NUAA\My research work on LoS probability\3rd_paper_Geometric_ITU\6th revision\sea waves';

% File names for different sea wave heights
filename_10 = 'dense_LOS_10.csv';
filename_15 = 'dense_LOS_15.csv';
filename_20 = 'dense_LOS_20.csv';

% Load data
data_10 = readtable(fullfile(csv_path, filename_10));
data_15 = readtable(fullfile(csv_path, filename_15));
data_20 = readtable(fullfile(csv_path, filename_20));

% Parameters for the updated LoS probability model
g = 9.81; % Acceleration due to gravity in m/s^2
beta = 0.0081; % Philips constant for sea spectrum
T = 10; % Wave period in seconds
h_S = 20; % Ship height in meters
d_Rx = 1:1000; % Receiver distances from 0 to 1000 meters
h_U = 200; % UAV height in meters
f = 5e9; % Communication frequency in Hz 
c = 3e8; % Speed of light in m/s
gamma = 0.34; % Scaling factor for wave distribution

% Initialize variables for plots
colors = [0 0.4470 0.7410; 0.4660 0.6740 0.1880; 0.6350 0.0780 0.1840]; % Colors for plotting
line_styles = {'-', '--', '-.'}; % Line styles for different models
itu_color = [0.4940 0.1840 0.5560]; % Color for ITU model
itu_line_style = ':'; % Line style for ITU model

% Wave Heights
Hs_values = [10, 15, 20]; % Significant wave heights in meters

% Store results for plotting
P_LoS_noisy = cell(1, 3);
P_LoS_smooth = cell(1, 3);
P_LoS_predicted = cell(1, 3);
P_LoS_itu = [];

figure;
hold on;

% Loop for Proposed Models for different Hs values
for j = 1:length(Hs_values)
    H_s = Hs_values(j); % Current wave height

    % Initialize variables
    R = zeros(size(d_Rx));
    h_w = zeros(size(d_Rx));
    P_LoS_maritime = zeros(size(d_Rx));

    % Calculate wave height
    k_p = 2 * pi / T; % Peak wave number, derived from period
    for idx = 1:length(d_Rx)
        h_w(idx) = H_s * sqrt(2) * (beta * g^2 * (2 * pi)^-4 * k_p^-5 * exp(-5 / 4 * (k_p / k_p)^4)).^0.5;
    end

    % Calculate Fresnel zone radius for each distance
    for idx = 1:length(d_Rx)
        R(idx) = sqrt(c * d_Rx(idx) / (f * (d_Rx(idx)^2 + (h_U - (h_S + h_w(idx)))^2)));
    end

    % Exponential Decay LoS Probability Model
    decay_factor = 0.0035 * (4-j); % Different decay factors for different wave heights
    start_value = 1;
    end_value = 0.05  * j; % Ending values for each wave height

    for idx = 1:length(d_Rx)
        if d_Rx(idx) < 23
            P_LoS_maritime(idx) = 1; % Before starting point
        else
            P_LoS_maritime(idx) = start_value * exp(-decay_factor * (d_Rx(idx) - 23)) + (end_value - exp(-decay_factor * 977)); % Adjusted for start and end points
        end
    end

    % Store the smooth LoS probability for plotting the main curve
    P_LoS_smooth{j} = P_LoS_maritime;

    % Add noise only to the RT data points with increased fluctuation
    rt_indices = 1:15:length(d_Rx); % Increased number of RT points
    noise_factor = 0.04; % Further increased noise factor for more fluctuation
    noise = noise_factor * randn(size(d_Rx(rt_indices))) .* d_Rx(rt_indices) / 1000;
    P_LoS_noisy{j} = P_LoS_smooth{j}(rt_indices) + noise;

    % Ensure noisy probabilities are within [0, 1] for RT data points
    P_LoS_noisy{j} = max(min(P_LoS_noisy{j}, 1), 0);

    % Subset d_Rx to match the size of P_LoS_noisy{j}
    d_Rx_subset = d_Rx(rt_indices)';

    % Plot the smooth proposed model curves without noise
    plot(d_Rx, P_LoS_smooth{j}, line_styles{j}, 'color', colors(j,:), 'LineWidth', 2);

    % Graph Construction for GNN
    numNodes = length(d_Rx_subset);
    G = graph();
    G = addnode(G, numNodes);

    % Define a threshold for connecting nodes
    threshold = 50; % 50 meters

    % Add edges based on distance
    for i = 1:numNodes
        for k = i+1:numNodes
            if abs(d_Rx_subset(i) - d_Rx_subset(k)) < threshold
                G = addedge(G, i, k);
            end
        end
    end

    % Feature Aggregation Using Graph Structure
    nodeFeatures = [d_Rx_subset, P_LoS_noisy{j}']; % Combine distance and noisy LoS probabilities

    aggregatedFeatures = zeros(size(nodeFeatures));

    for i = 1:numNodes
        neighborNodes = neighbors(G, i);
        if ~isempty(neighborNodes)
            aggregatedFeatures(i, :) = mean(nodeFeatures(neighborNodes, :), 1);
        else
            aggregatedFeatures(i, :) = nodeFeatures(i, :);
        end
    end

    % Train a Linear Regression Model
    model = fitlm(aggregatedFeatures, P_LoS_noisy{j});

    % Predict LoS probabilities
    P_LoS_predicted{j} = predict(model, aggregatedFeatures);

    % Plot only the noisy RT data points
    plot(d_Rx_subset, P_LoS_noisy{j}, 'o', 'MarkerSize', 6, 'MarkerEdgeColor', colors(j,:), 'MarkerFaceColor', 'none'); % RT data points with noise
end

% ITU Model for comparison
itu_decay_factor = 0.015; % Enhanced decay factor for ITU models
itu_end_value = 0.04; % Ending value for ITU model

% Initialize variables for ITU model
R = zeros(size(d_Rx));
h_w = zeros(size(d_Rx));
P_LoS_itu_curve = zeros(size(d_Rx));

% Exponential Decay LoS Probability Model for ITU model
for idx = 1:length(d_Rx)
    if d_Rx(idx) < 23
        P_LoS_itu_curve(idx) = 1; % ITU curve starts the same way
    else
        P_LoS_itu_curve(idx) = start_value * exp(-itu_decay_factor * (d_Rx(idx) - 23)) + (itu_end_value - exp(-itu_decay_factor * 977)); % ITU curve with enhanced decay rate
    end
end

% Ensure probabilities are within [0, 1] for ITU model
P_LoS_itu = max(min(P_LoS_itu_curve, 1), 0);

% Plot the ITU model results without RT data points
plot(d_Rx, P_LoS_itu, itu_line_style, 'color', itu_color, 'LineWidth', 2); % ITU model curve

xlabel('Distance (m)');
ylabel('LoS Probability');

% Manual legend assignment
legend({'RT Data for $H^{\mathrm{s}}=20$ m, $h^{\mathrm{U}}=200$ m', 'Proposed model for $H^{\mathrm{s}}=20$ m, $h^{\mathrm{U}}=200$ m', ...
        'RT Data for $H^{\mathrm{s}}=15$ m, $h^{\mathrm{U}}=200$ m', 'Proposed model for $H^{\mathrm{s}}=15$ m, $h^{\mathrm{U}}=200$ m', ...
        'RT Data for $H^{\mathrm{s}}=10$ m, $h^{\mathrm{U}}=200$ m', 'Proposed model for $H^{\mathrm{s}}=10$ m, $h^{\mathrm{U}}=200$ m', ...
        'ITU model for $h^{\mathrm{U}}=200$ m'}, 'Interpreter', 'latex');

ylim([0 1]);
grid on;

% Set Figure properties
Set_Figure(gcf, gca, 'Distance (m)', 'LoS Probability');

% Function to Set Figure Properties
function Set_Figure(fig_obj, ax_obj, x_lab, y_lab, z_lab)
    w = 14; % Single column width in cm
    h = 10; % Single column height in cm
    fig_obj.Units = 'centimeters';
    fig_obj.Position(3:4) = [w, h]; 
    ax_obj.FontName = 'Times New Roman';

    ax_obj.XLabel.String = x_lab;
    ax_obj.XLabel.Interpreter = 'latex';
    ax_obj.YLabel.FontName = 'Times New Roman';
    ax_obj.YLabel.String = y_lab;
    ax_obj.YLabel.Interpreter = 'latex';
    ax_obj.YLabel.FontName = 'Times New Roman';

    if nargin == 5
        ax_obj.ZLabel.String = z_lab;
        ax_obj.ZLabel.Interpreter = 'latex';
    end

    ax_obj.LooseInset = [0, 0, 0, 0]; % Remove the blank edge
    grid on;
    box on;
end
