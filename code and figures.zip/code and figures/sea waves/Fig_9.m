clc;
clear;
close all;

% Path for the CSV files
csv_path = 'D:\NUAA\My research work on LoS probability\3rd_paper_Geometric_ITU\6th revision\sea waves';
filenames = {'RT_data_h10.csv', 'RT_data_h15.csv', 'RT_data_h20.csv'}; % Corrected file names
heights = [10, 15, 20]; % Significant wave heights in meters
colors = [[230, 111, 81]; [42, 157, 142]; [65, 105, 225]] / 255; % Colors for plotting

% Parameters for plotting
num_bins = 25;
axis_limits = [0 1 0 0.12];

% Initialize a figure
figure;

% Loop through each CSV file to plot the histograms and Gaussian fits
for i = 1:length(filenames)
    subplot(3, 1, i); % Create a 3x1 subplot grid
    filename = fullfile(csv_path, filenames{i});
    data = readtable(filename); % Read the CSV data
    
    % Extract RT data from the first column of the table
    RT_data = data{:, 1}; % Extract RT data from the first column
    
    % Calculate dynamic mean (mu) and standard deviation (sigma) from data
    [mu_dynamic, sigma_dynamic] = normfit(RT_data);
    
    % Plot histogram and Gaussian fit
    plotHistogramAndGaussian(RT_data, heights(i), colors(i, :), num_bins, axis_limits, mu_dynamic, sigma_dynamic);
    
    % Set figure properties for each subplot
    Set_Figure(gcf, gca, 'Shadowing (dB)', 'PDF');
end

% Function to plot histogram and Gaussian fit
function plotHistogramAndGaussian(data, height, color, num_bins, axis_limits, mu, sigma)
    [counts, centers] = hist(data, num_bins); % Histogram counts and bin centers
    binWidth = centers(2) - centers(1); % Calculate bin width
    normalizedCounts = counts / (sum(counts) * binWidth); % Normalize histogram counts

    % Scale histogram height
    maxHistogramHeight = 0.125;
    normalizedCounts = normalizedCounts * (maxHistogramHeight / max(normalizedCounts));
    
    % Plot the histogram
    bar(centers, normalizedCounts, 'FaceColor', 'none', 'EdgeColor', color, 'BarWidth', 1, 'LineWidth', 0.75);
    hold on;
    
    % Fit Gaussian to data
    xFit = linspace(min(data), max(data), 1000);
    yFit = normpdf(xFit, mu, sigma);

    % Normalize Gaussian fit to match histogram scale
    yFit = yFit * (0.12 / max(yFit));
    
    % Plot the Gaussian fit
    plot(xFit, yFit, 'LineWidth', 1.5, 'Color', color);
    
    % Set axis limits
    axis(axis_limits);
    
    % Enable grid
    grid on;
    
    % Update legend and title
    legend({['RT Data for H^\text{s}=' num2str(height)], ...
            ['Gaussian fit: \(\mu\) = ' num2str(mu, '%.3f') ', \(\sigma\) = ' num2str(sigma, '%.3f')]}, ...
            'Interpreter', 'latex', 'Location', 'northeast');
    %title(['RT Distribution and LoS Probability for h=' num2str(height)]);
    
    % Adjust subplot for better fit
    set(gca, 'FontSize', 12); % Increase font size for readability
end

% Function to Set Figure Properties
function Set_Figure(fig_obj, ax_obj, x_lab, y_lab, z_lab)
    w = 18; % Width in cm, increased for better layout
    h = 15; % Height in cm, increased for better layout
    fig_obj.Units = 'centimeters';
    fig_obj.Position(3:4) = [w, h]; 
    ax_obj.FontName = 'Times New Roman';

    ax_obj.XLabel.String = x_lab;
    ax_obj.XLabel.Interpreter = 'latex';
    ax_obj.YLabel.String = y_lab;
    ax_obj.YLabel.Interpreter = 'latex';

    if nargin == 5
        ax_obj.ZLabel.String = z_lab;
        ax_obj.ZLabel.Interpreter = 'latex';
    end

    ax_obj.LooseInset = max(ax_obj.TightInset, 0.02); % Add small padding
    grid on;
    box on;
end
