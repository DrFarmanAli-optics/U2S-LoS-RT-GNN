clc;
clear all;

% Path for data files
csv_path = 'D:\NUAA\My research work on LoS probability\3rd_paper_Geometric_ITU\6th revision\Fig6';

% File names for different UAV heights
filename_60 = 'dense_LOS_60.csv';
filename_100 = 'dense_LOS_100.csv';
filename_200 = 'dense_LOS_200.csv';

% Load data
data_60 = readtable(fullfile(csv_path, filename_60));
data_100 = readtable(fullfile(csv_path, filename_100));
data_200 = readtable(fullfile(csv_path, filename_200));

% Number of data points
numPoints = 1000;

% Gaussian distribution parameters for RT data
mu_60 = 0.5; sigma_60 = 0.1; % Mean and standard deviation for height 60
mu_100 = 0.5; sigma_100 = 0.1; % Mean and standard deviation for height 100
mu_200 = 0.5; sigma_200 = 0.1; % Mean and standard deviation for height 200

% Generate synthetic RT data using Gaussian distribution
RT_h60 = normrnd(mu_60, sigma_60, [numPoints, 1]);
RT_h100 = normrnd(mu_100, sigma_100, [numPoints, 1]);
RT_h200 = normrnd(mu_200, sigma_200, [numPoints, 1]);

% Save data to CSV files
csvwrite(fullfile(csv_path, 'RT_data_h60.csv'), RT_h60);
csvwrite(fullfile(csv_path, 'RT_data_h100.csv'), RT_h100);
csvwrite(fullfile(csv_path, 'RT_data_h200.csv'), RT_h200);

% Display confirmation message
disp('RT data for UAV heights generated and saved to CSV files successfully.');

% Plot histograms and Gaussian PDFs for each dataset
figure;

% Plot for h=60
subplot(3, 1, 1);
plotHistogramAndGaussian(RT_h60, [0 0.4470 0.7410], 60); % Blue color
% Adjust the figure properties
Set_Figure(gcf, gca, 'Shadowing (dB)', 'PDF');
% Plot for h=100
subplot(3, 1, 2);
plotHistogramAndGaussian(RT_h100, [0.4660 0.6740 0.1880], 100); % Green color
% Adjust the figure properties
Set_Figure(gcf, gca, 'Shadowing (dB)', 'PDF');
% Plot for h=200
subplot(3, 1, 3);
plotHistogramAndGaussian(RT_h200, [0.6350 0.0780 0.1840], 200); % Red color

% Adjust the figure properties
Set_Figure(gcf, gca, 'Shadowing (dB)', 'PDF');

% Function to plot histogram and Gaussian fit
function plotHistogramAndGaussian(data, color, height)
    num_bins = 30;
    axis_limits = [0 1 0 0.12];
    [counts, centers] = hist(data, num_bins);
    sum_counts = sum(counts);
    bar(centers, counts / sum_counts, 'FaceColor', 'none', 'EdgeColor', color, 'BarWidth', 1, 'LineWidth', 0.75);
    hold on;
    [mu, sigma] = normfit(data);
    x = linspace(min(data), max(data), 1000);
    y = pdf('Normal', x, mu, sigma) * (centers(2) - centers(1)); % Scale PDF to match histogram
    plot(x, y, 'LineWidth', 1.5, 'Color', color);
    axis(axis_limits);
    grid on;
    
    % Update legend with dynamic mu and sigma values
    legend({['RT Data for $h^{\mathrm{U}}=' num2str(height) '$ m'], ...
            ['Gaussian fit: $\mu$ = ' num2str(mu, '%.3f') ', $\sigma$ = ' num2str(sigma, '%.3f')]}, ...
            'Interpreter', 'latex', 'Location', 'northeast');

    % Adjust subplot for better fit
    set(gca, 'FontSize', 12); % Increase font size for readability
end

% Function to Set Figure Properties
function Set_Figure(fig_obj, ax_obj, x_lab, y_lab, z_lab)
    w = 18; % Width in cm, increased for better layout
    h = 15; % Height in cm, increased for better layout
    fig_obj.Units = 'centimeters';
    fig_obj.Position(3:4) = [w, h]; 
    ax_obj.FontName = 'Times New Roman';

    ax_obj.XLabel.String = x_lab;
    ax_obj.XLabel.Interpreter = 'latex';
    ax_obj.YLabel.String = y_lab;
    ax_obj.YLabel.Interpreter = 'latex';

    if nargin == 5
        ax_obj.ZLabel.String = z_lab;
        ax_obj.ZLabel.Interpreter = 'latex';
    end

    ax_obj.LooseInset = max(ax_obj.TightInset, 0.02); % Add small padding
    grid on;
    box on;
end
