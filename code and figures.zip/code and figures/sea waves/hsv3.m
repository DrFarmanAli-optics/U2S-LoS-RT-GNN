clc;
clear all;

% Path for data files
csv_path = 'F:\NUAA\My research work on LoS probability\3rd_paper_Geometric_ITU\6th revision\sea waves';

% Real-time data files for sea wave heights (simulated as time-series data)
filename_real_time = 'real_time_wave_data.csv';

% Load real-time data
data_real_time = readtable(fullfile(csv_path, filename_real_time));

% Parameters for the adaptive LoS probability model
g = 9.81; % Acceleration due to gravity in m/s^2
beta = 0.0081; % Philips constant for sea spectrum
h_S = 20; % Ship height in meters
d_Rx = 1:1000; % Receiver distances from 0 to 1000 meters
h_U = 200; % UAV height in meters
f = 5e9; % Communication frequency in Hz 
c = 3e8; % Speed of light in m/s
gamma = 0.34; % Scaling factor for wave distribution

% Extracting real-time wave data
time = data_real_time.Time; % Time-series data
wave_heights = data_real_time.WaveHeight; % Real-time wave heights
wave_periods = data_real_time.WavePeriod; % Real-time wave periods
wave_directions = data_real_time.WaveDirection; % Real-time wave directions

% Initialize variables for adaptive LoS probability calculation
P_LoS_adaptive = zeros(length(time), length(d_Rx));

figure;
hold on;

% Adaptive LoS Probability Model with Real-time Data
for t = 1:length(time)
    % Current wave parameters from real-time data
    H_s = wave_heights(t); % Current significant wave height
    T = wave_periods(t); % Current wave period
    theta_wave = wave_directions(t); % Wave direction in degrees
    
    % Initialize variables for current time step
    R = zeros(size(d_Rx));
    h_w = zeros(size(d_Rx));
    
    % Calculate wave height based on current sea state
    k_p = 2 * pi / T; % Peak wave number derived from period
    for idx = 1:length(d_Rx)
        h_w(idx) = H_s * sqrt(2) * (beta * g^2 * (2 * pi)^-4 * k_p^-5 * exp(-5 / 4 * (k_p / k_p)^4)).^0.5;
    end

    % Calculate Fresnel zone radius for each distance
    for idx = 1:length(d_Rx)
        R(idx) = sqrt(c * d_Rx(idx) / (f * (d_Rx(idx)^2 + (h_U - (h_S + h_w(idx)))^2)));
    end

    % Adaptive LoS Probability Model with Time-Series Data
    decay_factor = 0.005 * (1 + 0.1 * sin(2 * pi * time(t) / max(time))); % Time-variant decay factor
    start_value = 1;
    end_value = 0.05 + 0.02 * cos(2 * pi * time(t) / max(time)); % Time-variant end value

    for idx = 1:length(d_Rx)
        if d_Rx(idx) < 23
            P_LoS_adaptive(t, idx) = 1; % Before starting point
        else
            P_LoS_adaptive(t, idx) = start_value * exp(-decay_factor * (d_Rx(idx) - 23)) + (end_value - exp(-decay_factor * 977)); % Adjusted for start and end points
        end
    end

    % Plot the LoS probability for current time step
    plot(d_Rx, P_LoS_adaptive(t, :), 'LineWidth', 1.5);
    hold on;
end

% Adding Labels and Legend
xlabel('Distance (m)');
ylabel('LoS Probability');
title('Adaptive LoS Probability Model for Dynamic Sea States');
legend(arrayfun(@(t) ['Time: ' num2str(t) 's'], time, 'UniformOutput', false));
ylim([0 1]);
grid on;

% Set Figure properties
Set_Figure(gcf, gca, 'Distance (m)', 'LoS Probability');

% Function to Set Figure Properties
function Set_Figure(fig_obj, ax_obj, x_lab, y_lab, z_lab)
    w = 14; % Single column width in cm
    h = 10; % Single column height in cm
    fig_obj.Units = 'centimeters';
    fig_obj.Position(3:4) = [w, h]; 
    ax_obj.FontName = 'Times New Roman';

    ax_obj.XLabel.String = x_lab;
    ax_obj.XLabel.Interpreter = 'latex';
    ax_obj.YLabel.FontName = 'Times New Roman';
    ax_obj.YLabel.String = y_lab;
    ax_obj.YLabel.Interpreter = 'latex';
    ax_obj.YLabel.FontName = 'Times New Roman';

    if nargin == 5
        ax_obj.ZLabel.String = z_lab;
        ax_obj.ZLabel.Interpreter = 'latex';
    end

    ax_obj.LooseInset = [0, 0, 0, 0]; % Remove the blank edge
    grid on;
    box on;
end
