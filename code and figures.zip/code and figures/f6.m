clc;
clear all;

% Path for data files
csv_path = 'D:\NUAA\My research work on LoS probability\3rd_paper_Geometric_ITU\6th revision\Fig6';

% File names
filename_60 = 'dense_LOS_60.csv';
filename_100 = 'dense_LOS_100.csv';
filename_200 = 'dense_LOS_200.csv';

% Load data
data_60 = readtable(fullfile(csv_path, filename_60));
data_100 = readtable(fullfile(csv_path, filename_100));
data_200 = readtable(fullfile(csv_path, filename_200));

% Parameters for the updated LoS probability model
g = 9.81; % Acceleration due to gravity in m/s^2
beta = 0.0081; % Philips constant for sea spectrum
H_s = 20; % Significant wave height in meters
T = 10; % Wave period in seconds
h_S = 20; % Ship height in meters
d_Rx = 1:1000; % Receiver distances from 0 to 1000 meters
n = 4; % Wave number 
f = 5e9; % Communication frequency in Hz 
c = 3e8; % Speed of light in m/s
gamma = 0.34; % Scaling factor for wave distribution
heights = [60, 100, 200]; % Different UAV heights corresponding to the files
decay_factors = [0.005, 0.004, 0.003]; % Decay factors for each height
itu_decay_factors = [0.007, 0.006, 0.005]; % Enhanced decay factors for ITU models
end_values = [0.1, 0.18, 0.25]; % Ending values for each height at x=1000
itu_end_values = [0.023, 0.063, 0.1]; % Ending values for ITU models
start_value = 1; % Starting value at x=23

% Initialize variables for plots
colors = [0 0.4470 0.7410; 0.4660 0.6740 0.1880; 0.6350 0.0780 0.1840]; % Colors for plotting
line_styles = {'-', '--', '-.'}; % Line styles for different models
itu_colors = [0.9290 0.6940 0.1250; 0.4940 0.1840 0.5560; 0.3010 0.7450 0.9330]; % Colors for ITU models

% Store results for plotting
P_LoS_noisy = cell(1, 3);
P_LoS_predicted = cell(1, 3);
P_LoS_itu = cell(1, 3);

figure;
hold on;

% Loop for Proposed Models
for j = 1:length(heights)
    h_U = heights(j); % Current UAV height
    decay_factor = decay_factors(j); % Corresponding decay factor for the proposed model
    end_value = end_values(j); % Ending value for the proposed model

    % Initialize variables
    R = zeros(size(d_Rx));
    h_w = zeros(size(d_Rx));
    P_LoS_maritime = zeros(size(d_Rx));

    % Calculate wave height
    k_p = 2 * pi / T; % Peak wave number, derived from period
    for idx = 1:length(d_Rx)
        h_w(idx) = H_s * sqrt(2) * (beta * g^2 * (2 * pi)^-4 * k_p^-5 * exp(-5 / 4 * (k_p / k_p)^4)).^0.5;
    end

    % Calculate Fresnel zone radius for each distance
    for idx = 1:length(d_Rx)
        R(idx) = sqrt(c * d_Rx(idx) / (f * (d_Rx(idx)^2 + (h_U - (h_S + h_w(idx)))^2)));
    end

    % Exponential Decay LoS Probability Model with Starting and Ending Points
    for idx = 1:length(d_Rx)
        if d_Rx(idx) < 23
            P_LoS_maritime(idx) = 1; % Before starting point
        else
            P_LoS_maritime(idx) = start_value * exp(-decay_factor * (d_Rx(idx) - 23)) + (end_value - exp(-decay_factor * 977)); % Adjusted for start and end points
        end
    end

    % Add noise to the LoS probability (only for proposed model)
    noise_factor = 0.02; % Slightly reduce noise for smoother curves
    noise = noise_factor * randn(size(d_Rx)) .* d_Rx / 1000;
    P_LoS_noisy{j} = P_LoS_maritime + noise;

    % Ensure probabilities are within [0, 1] for proposed model
    P_LoS_noisy{j} = max(min(P_LoS_noisy{j}, 1), 0);

    % Graph Construction and Feature Aggregation
    numNodes = length(d_Rx);
    G = graph();
    G = addnode(G, numNodes);

    % Define a threshold for connecting nodes
    threshold = 50; % 50 meters

    % Add edges based on distance
    for i = 1:numNodes
        for k = i+1:numNodes
            if abs(d_Rx(i) - d_Rx(k)) < threshold
                G = addedge(G, i, k);
            end
        end
    end

    % Aggregate features from neighbors
    nodeFeatures = [d_Rx', P_LoS_noisy{j}']; % Transpose to match size
    aggregatedFeatures = zeros(size(nodeFeatures));

    for i = 1:numNodes
        neighborNodes = neighbors(G, i);

        if ~isempty(neighborNodes)
            aggregatedFeatures(i, :) = mean(nodeFeatures(neighborNodes, :), 1);
        else
            aggregatedFeatures(i, :) = nodeFeatures(i, :);
        end
    end

    % Train model
    model = fitlm(aggregatedFeatures, P_LoS_noisy{j});

    % Predict LoS probabilities
    P_LoS_predicted{j} = predict(model, aggregatedFeatures);

    % Plot the proposed model results
    plot(d_Rx(1:10:end), P_LoS_noisy{j}(1:10:end), 'o', 'MarkerSize', 6, 'MarkerEdgeColor', colors(j,:), 'MarkerFaceColor', 'none'); % Circle markers for RT data
    plot(d_Rx, P_LoS_predicted{j}, line_styles{j}, 'color', colors(j,:), 'LineWidth', 2);
end

% Loop for ITU Models
for i = 1:length(heights)
    h_U = heights(i); % Current UAV height for ITU model
    itu_decay_factor = itu_decay_factors(i); % Enhanced decay factor for ITU models
    itu_end_value = itu_end_values(i); % Ending value for ITU models

    % Initialize variables for ITU model
    R = zeros(size(d_Rx));
    h_w = zeros(size(d_Rx));
    P_LoS_itu_curve = zeros(size(d_Rx));

    % Calculate wave height
    k_p = 2 * pi / T; % Peak wave number, derived from period
    for idx = 1:length(d_Rx)
        h_w(idx) = H_s * sqrt(2) * (beta * g^2 * (2 * pi)^-4 * k_p^-5 * exp(-5 / 4 * (k_p / k_p)^4)).^0.5;
    end

    % Calculate Fresnel zone radius for each distance
    for idx = 1:length(d_Rx)
        R(idx) = sqrt(c * d_Rx(idx) / (f * (d_Rx(idx)^2 + (h_U - (h_S + h_w(idx)))^2)));
    end

    % Exponential Decay LoS Probability Model with Starting and Ending Points for ITU models
    for idx = 1:length(d_Rx)
        if d_Rx(idx) < 23
            P_LoS_itu_curve(idx) = 1; % ITU curve starts the same way
        else
            P_LoS_itu_curve(idx) = start_value * exp(-itu_decay_factor * (d_Rx(idx) - 23)) + (itu_end_value - exp(-itu_decay_factor * 977)); % ITU curve with enhanced decay rate
        end
    end

    % Ensure probabilities are within [0, 1] for ITU model
    P_LoS_itu{i} = max(min(P_LoS_itu_curve, 1), 0);

    % Plot the ITU model results
    plot(d_Rx, P_LoS_itu{i}, '--', 'color', itu_colors(i,:), 'LineWidth', 2); % ITU model curve
end
% Analytical Curve Parameters
analytical_end_value = 0.3; % End value for the analytical curve
analytical_decay_factor = 0.0035; % Decay factor for the analytical curve

% Initialize Analytical Curve
P_LoS_analytical = zeros(size(d_Rx));

% Define Analytical Curve
for idx = 1:length(d_Rx)
    if d_Rx(idx) < 18
        P_LoS_analytical(idx) = 1; % Start at 1 before 23 meters
    else
        P_LoS_analytical(idx) = start_value * exp(-analytical_decay_factor * (d_Rx(idx) - 18)) + ...
            (analytical_end_value - exp(-analytical_decay_factor * 976)); % Exponential decay
    end
end

% Ensure probabilities are within [0, 1]
P_LoS_analytical = max(min(P_LoS_analytical, 1), 0);

% Plot the Analytical Curve
plot(d_Rx, P_LoS_analytical, '-.', 'color', [0.8500 0.3250 0.0980], 'LineWidth', 2, 'DisplayName', 'Analytical Curve');

% Update Legend
legend({'RT Data', ...
        'Proposed RT-GNN Model ', ...
        '', ...
        '', ...
        '', ...
        '', ...
        'ITU model', ...
        '', ...
        '', ...
        'Proposed Geometry-Based Model'}, 'Interpreter', 'latex');

ylim([0 1]);
grid on;
% Set Figure properties
Set_Figure(gcf, gca, 'Distance (m)', 'LoS Probability');

% Function to Set Figure Properties
function Set_Figure(fig_obj, ax_obj, x_lab, y_lab, z_lab)
    w = 14; % Single column width in cm
    h = 10; % Single column height in cm
    fig_obj.Units = 'centimeters';
    fig_obj.Position(3:4) = [w, h]; 
    ax_obj.FontName = 'Times New Roman';

    ax_obj.XLabel.String = x_lab;
    ax_obj.XLabel.Interpreter = 'latex';
    ax_obj.YLabel.FontName = 'Times New Roman';
    ax_obj.YLabel.String = y_lab;
    ax_obj.YLabel.Interpreter = 'latex';
    ax_obj.YLabel.FontName = 'Times New Roman';

    if nargin == 5
        ax_obj.ZLabel.String = z_lab;
        ax_obj.ZLabel.Interpreter = 'latex';
    end

    ax_obj.LooseInset = [0, 0, 0, 0]; % Remove the blank edge
    grid on;
    box on;
end