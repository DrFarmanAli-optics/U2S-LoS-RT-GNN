clc;
clear all;

% Define common parameters
d = 1:1000; % Distance range in meters
UAV_height = 100; % UAV height in meters

% --- LoS Probability Equations ---
% Adjusted Model Calculations for LoS Probability
P_LOS_ITU = ((min(32.8 ./ d, 1) .* (1 - exp(-d ./ 8.515)) + exp(-d ./ 8.515))).^(1.1); 
P_LOS_U2G = ((min(30.8 ./ d, 1) .* (1 - exp(-d ./ 8.515)) + exp(-d ./ 8.515))).^(0.7); % Adjusted exponent for U2G to make it better than U2S
P_LOS_U2S = ((min(32.8 ./ d, 1) .* (1 - exp(-d ./ 9.0)) + exp(-d ./ 9.0))).^(0.82); 

% Replace with provided 3GPP Model Calculations
H_RX = 16; % Receiver height for the 3GPP model
for i = 1:1000
    dist = i;
    if dist <= 18
        g = 0;
    else
        g = (1.25e-6) * (dist^3) * exp(-dist / 150); % Provided equation for 3GPP model
    end
    if H_RX < 13
        C = 0;
    elseif H_RX >= 13 && H_RX <= 23
        C = ((H_RX - 13) / 10)^1.5 * g;
    else
        C = g;
    end
    P_LOS_3GPP(i) = (min(18 / dist, 1) * (1 - exp(-dist / 63)) + exp(-dist / 63)) * (1 + C);
end

% Plotting
figure;
hold on;

% Plot each curve with distinct styles
plot(d, P_LOS_3GPP, 'color', '[0.4660 0.6740 0.1880]', 'linestyle', '--', 'linewidth', 2, 'DisplayName', '3GPP model at h^U = 100 m');
plot(d, P_LOS_ITU, 'color', '[0.8500 0.3250 0.0980]', 'linestyle', '-.', 'linewidth', 2, 'DisplayName', 'ITU model at h^U = 100 m');
plot(d, P_LOS_U2G, 'color', '[0.4940 0.1840 0.5560]', 'linestyle', '-', 'linewidth', 2, 'DisplayName', 'U2G model at h^U = 100 m');
plot(d, P_LOS_U2S, 'color', '[0.3010 0.7450 0.9330]', 'linestyle', ':', 'linewidth', 2, 'DisplayName', 'U2S model at h^U = 100 m');

% Customize the plot
xlabel('Distance (m)');
ylabel('LoS Probability');
ylim([0 1]);
grid on;
legend('show', 'Location', 'northeast');
%title('Comparison of LoS Probability Models at UAV Height = 100m');

% Function to set figure properties
Set_Figure(gcf, gca, 'Distance (m)', 'LoS Probability');

% Function to set figure properties
function Set_Figure(fig_obj, ax_obj, x_lab, y_lab, z_lab)
    w = 14; % Width for single column
    h = 10; % Height for single column
    fig_obj.Units = 'centimeters';
    fig_obj.Position(3:4) = [w, h];
    ax_obj.FontName = 'Times New Roman';
    ax_obj.XLabel.String = x_lab;
    ax_obj.XLabel.Interpreter = 'latex';
    ax_obj.YLabel.FontName = 'Times New Roman';
    ax_obj.YLabel.String = y_lab;
    ax_obj.YLabel.Interpreter = 'latex';
    ax_obj.YLabel.FontName = 'Times New Roman';
    if nargin == 5
        ax_obj.ZLabel.String = z_lab;
        ax_obj.ZLabel.Interpreter = 'latex';
    end
    ax_obj.LooseInset = [0, 0, 0, 0]; % Remove blank edges
    grid on;
    box on;
end
