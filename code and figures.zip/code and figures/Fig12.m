% data from RT simulations or measurements
actual_los_probabilities = [0.95, 0.87, 0.78, 0.70, 0.63, 0.58, 0.50, 0.45, 0.38, 0.30];

% Predicted LoS probabilities from proposed U2S model
predicted_los_probabilities = [0.93, 0.85, 0.80, 0.68, 0.65, 0.56, 0.52, 0.44, 0.40, 0.32];

% Calculate Mean Absolute Error (MAE)
mae = mean(abs(actual_los_probabilities - predicted_los_probabilities));

% Calculate Root Mean Squared Error (RMSE)
rmse = sqrt(mean((actual_los_probabilities - predicted_los_probabilities).^2));

% Calculate R-squared (Coefficient of Determination)
SS_res = sum((actual_los_probabilities - predicted_los_probabilities).^2);
SS_tot = sum((actual_los_probabilities - mean(actual_los_probabilities)).^2);
r2 = 1 - (SS_res / SS_tot);

% Display the results
fprintf('Mean Absolute Error (MAE): %.4f\n', mae);
fprintf('Root Mean Squared Error (RMSE): %.4f\n', rmse);
fprintf('R-squared (R2 Score): %.4f\n', r2);

% Plot the actual vs. predicted values
figure;
plot(actual_los_probabilities, 'bo-', 'LineWidth', 1.5);
hold on;
plot(predicted_los_probabilities, 'rx--', 'LineWidth', 1.5);
xlabel('Sample Points');
ylabel('LoS Probability');
%title('Actual vs. Predicted LoS Probabilities');
legend('Actual LoS Probabilities', 'Predicted LoS Probabilities', 'Location', 'Best');
grid on;
hold off;
