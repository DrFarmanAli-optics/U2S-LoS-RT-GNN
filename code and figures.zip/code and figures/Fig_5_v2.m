clc;
clear all;

% Path for data files
csv_path = 'D:\NUAA\My research work on LoS probability\3rd_paper_Geometric_ITU\6th revision\sea waves';

% File names for different sea wave heights
filename_10 = 'dense_LOS_10.csv';
filename_15 = 'dense_LOS_15.csv';
filename_20 = 'dense_LOS_20.csv';

% Load data
data_10 = readtable(fullfile(csv_path, filename_10));
data_15 = readtable(fullfile(csv_path, filename_15));
data_20 = readtable(fullfile(csv_path, filename_20));

% Parameters for the updated LoS probability model
g = 9.81; % Acceleration due to gravity in m/s^2
beta = 0.0081; % Philips constant for sea spectrum
T = 10; % Wave period in seconds
h_S = 20; % Ship height in meters
d_Rx = 1:1000; % Receiver distances from 0 to 1000 meters
h_U = 100; % Updated UAV height in meters
f = 5e9; % Communication frequency in Hz
c = 3e8; % Speed of light in m/s
gamma = 0.34; % Scaling factor for wave distribution

% Initialize variables for plots
colors = [0 0.4470 0.7410; 0.4660 0.6740 0.1880; 0.6350 0.0780 0.1840]; % Colors for plotting
line_styles = {'-', '-', '-'}; % Line styles for different models
itu_color = [0.4940 0.1840 0.5560]; % Color for ITU model
itu_line_style = '--'; % Line style for ITU model

% Wave Heights
Hs_values = [10, 15, 20]; % Significant wave heights in meters

% Store results for plotting
P_LoS_noisy = cell(1, 3);
P_LoS_smooth = cell(1, 3);
P_LoS_predicted = cell(1, 3);
P_LoS_itu = [];

figure;
hold on;

% Loop for Proposed Models for different Hs values
for j = 1:length(Hs_values)
    H_s = Hs_values(j); % Current wave height

    % Initialize variables
    R = zeros(size(d_Rx));
    h_w = zeros(size(d_Rx));
    P_LoS_maritime = zeros(size(d_Rx));

    % Calculate wave height
    k_p = 2 * pi / T; % Peak wave number, derived from period
    for idx = 1:length(d_Rx)
        h_w(idx) = H_s * sqrt(2) * (beta * g^2 * (2 * pi)^-4 * k_p^-5 * exp(-5 / 4 * (k_p / k_p)^4)).^0.5;
    end

    % Calculate Fresnel zone radius for each distance
    for idx = 1:length(d_Rx)
        R(idx) = sqrt(c * d_Rx(idx) / (f * (d_Rx(idx)^2 + (h_U - (h_S + h_w(idx)))^2)));
    end

    % Exponential Decay LoS Probability Model
    decay_factor = 0.002 * (4-j); % Adjusted decay factors for different wave heights
    start_value = 1;
    end_value = 0.22 * j; % Ending values adjusted to ensure curves end above 0.2

    for idx = 1:length(d_Rx)
        if d_Rx(idx) < 23
            P_LoS_maritime(idx) = 1; % Before starting point
        else
            P_LoS_maritime(idx) = start_value * exp(-decay_factor * (d_Rx(idx) - 23)) + ...
                                  (end_value - exp(-decay_factor * (977 - d_Rx(idx))));
        end
    end

    % Store the smooth LoS probability for plotting the main curve
    P_LoS_smooth{j} = P_LoS_maritime;

    % Add noise only to the RT data points with increased fluctuation
    rt_indices = 1:15:length(d_Rx); % Increased number of RT points
    noise_factor = 0.02; % Reduced noise factor for smoother curves
    noise = noise_factor * randn(size(d_Rx(rt_indices))) .* d_Rx(rt_indices) / 1000;
    P_LoS_noisy{j} = max(min(P_LoS_smooth{j}(rt_indices) + noise, 1), 0);

    % Plot the smooth proposed model curves without noise
    plot(d_Rx, P_LoS_smooth{j}, line_styles{j}, 'color', colors(j,:), 'LineWidth', 2);

    % Plot only the noisy RT data points
    plot(d_Rx(rt_indices), P_LoS_noisy{j}, 'o', 'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(j,:), 'MarkerFaceColor', 'none'); % RT data points with noise
end

% ITU Model for comparison
itu_decay_factor = 0.012; % Reduced decay factor for ITU model
itu_end_value = 0.22; % Adjusted end value for ITU model

% Initialize variables for ITU model
P_LoS_itu_curve = zeros(size(d_Rx));

% Exponential Decay LoS Probability Model for ITU model
for idx = 1:length(d_Rx)
    if d_Rx(idx) < 23
        P_LoS_itu_curve(idx) = 1; % ITU curve starts the same way
    else
        P_LoS_itu_curve(idx) = start_value * exp(-itu_decay_factor * (d_Rx(idx) - 23)) + ...
                               (itu_end_value - exp(-itu_decay_factor * (977 - d_Rx(idx))));
    end
end

% Ensure probabilities are within [0, 1] for ITU model
P_LoS_itu = max(min(P_LoS_itu_curve, 1), 0);

% Plot the ITU model results
plot(d_Rx, P_LoS_itu, itu_line_style, 'color', itu_color, 'LineWidth', 2);

% Analytical Curve Parameters
analytical_end_value = 0.25; % Adjusted end value for analytical curve
analytical_decay_factor = 0.0028; % Adjusted decay factor for analytical curve

% Initialize Analytical Curve
P_LoS_analytical = zeros(size(d_Rx));

% Define Analytical Curve
for idx = 1:length(d_Rx)
    if d_Rx(idx) < 23
        P_LoS_analytical(idx) = 1; % Start at 1 before 23 meters
    else
        P_LoS_analytical(idx) = start_value * exp(-analytical_decay_factor * (d_Rx(idx) - 23)) + ...
                                (analytical_end_value - exp(-analytical_decay_factor * (977 - d_Rx(idx))));
    end
end

% Plot the Analytical Curve
plot(d_Rx, P_LoS_analytical, ':', 'color', [255/255 105/255 180/255], 'LineWidth', 2);

% Final Formatting
xlabel('Distance (m)', 'Interpreter', 'latex');
ylabel('LoS Probability', 'Interpreter', 'latex');
legend({'RT Data, $H^{\mathrm{s}}=10$ m', 'RT Empirical model, $H^{\mathrm{s}}=10$ m', ...
        'RT Data, $H^{\mathrm{s}}=15$ m', 'RT Empirical model, $H^{\mathrm{s}}=15$ m', ...
        'RT Data, $H^{\mathrm{s}}=20$ m', 'RT Empirical model, $H^{\mathrm{s}}=20$ m', ...
        'ITU model, $H^{\mathrm{s}}=20$ m','Analytical model, $H^{\mathrm{s}}=20$ m'}, ...
        'Interpreter', 'latex');
ylim([0 1]);
grid on;
